const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();

// ─────────────────────────────────────────────────────────────
// 🔧 VENDOS STRINGËN E MONGODB KËTU:
const MONGODB_URI = 'mongodb+srv://<username>:<password>@cluster.mongodb.net/borxhet?retryWrites=true&w=majority';
// ─────────────────────────────────────────────────────────────

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
mongoose.connect(MONGODB_URI)
  .then(() => console.log('✅ Lidhja me MongoDB u krye me sukses!'))
  .catch(err => console.error('❌ Gabim gjatë lidhjes me MongoDB:', err));

// Schema & Model
const borxhSchema = new mongoose.Schema({
  emri: { type: String, required: true, trim: true },
  shuma: { type: Number, required: true },
  data: { type: Date, default: Date.now }
});

const Borxh = mongoose.model('Borxh', borxhSchema);

// ── REST API Routes ──────────────────────────────────────────

// GET /api/borxhet - Merr të gjitha borxhet
app.get('/api/borxhet', async (req, res) => {
  try {
    const borxhet = await Borxh.find().sort({ data: -1 });
    res.json(borxhet);
  } catch (err) {
    res.status(500).json({ mesazh: 'Gabim gjatë marrjes së borxheve.' });
  }
});

// POST /api/borxhet - Shto borxh të ri
app.post('/api/borxhet', async (req, res) => {
  try {
    const { emri, shuma } = req.body;
    if (!emri || !shuma) {
      return res.status(400).json({ mesazh: 'Emri dhe shuma janë të detyrueshme.' });
    }
    const borxhiRi = new Borxh({ emri, shuma: Number(shuma) });
    await borxhiRi.save();
    res.status(201).json(borxhiRi);
  } catch (err) {
    res.status(500).json({ mesazh: 'Gabim gjatë shtimit të borxhit.' });
  }
});

// DELETE /api/borxhet/:id - Fshi borxhin
app.delete('/api/borxhet/:id', async (req, res) => {
  try {
    await Borxh.findByIdAndDelete(req.params.id);
    res.json({ mesazh: 'Borxhi u fshi me sukses.' });
  } catch (err) {
    res.status(500).json({ mesazh: 'Gabim gjatë fshirjes së borxhit.' });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Serveri po ekzekutohet në portin ${PORT}`);
});
