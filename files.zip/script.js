/* ── Libri i Borxheve — script.js ─────────────────── */

const API = '/api/borxhet';

// DOM refs
const addForm     = document.getElementById('addForm');
const emriInput   = document.getElementById('emri');
const shumaInput  = document.getElementById('shuma');
const formMsg     = document.getElementById('formMsg');
const listEl      = document.getElementById('borxhetList');
const emptyState  = document.getElementById('emptyState');
const totalEl     = document.getElementById('totalAmount');
const overlay     = document.getElementById('modalOverlay');
const btnCancel   = document.getElementById('btnCancel');
const btnConfirm  = document.getElementById('btnConfirm');

let pendingDeleteId = null;

// ── Helpers ────────────────────────────────────────
function showMsg(text, type = 'error') {
  formMsg.textContent = text;
  formMsg.className   = `form-msg ${type}`;
  setTimeout(() => { formMsg.textContent = ''; formMsg.className = 'form-msg'; }, 3000);
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('sq-AL', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatAmount(n) {
  return Number(n).toLocaleString('sq-AL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}

function avatarLetter(name) {
  return name.trim().charAt(0).toUpperCase();
}

// ── Fetch & Render ─────────────────────────────────
async function loadBorxhet() {
  try {
    const res  = await fetch(API);
    const data = await res.json();
    renderList(data);
  } catch {
    showMsg('Gabim: nuk mund të merren të dhënat.');
  }
}

function renderList(borxhet) {
  // Clear existing items (keep empty state)
  listEl.innerHTML = '';

  if (!borxhet.length) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <p>Nuk ka borxhe të regjistruara ende.</p>
      </div>`;
    totalEl.textContent = '0.00 €';
    return;
  }

  const total = borxhet.reduce((sum, b) => sum + b.shuma, 0);
  totalEl.textContent = formatAmount(total);

  borxhet.forEach(b => {
    const item = document.createElement('div');
    item.className = 'debt-item';
    item.dataset.id = b._id;
    item.innerHTML = `
      <div class="debt-left">
        <div class="debt-avatar">${avatarLetter(b.emri)}</div>
        <div>
          <div class="debt-name">${escHtml(b.emri)}</div>
          <div class="debt-date">${formatDate(b.data)}</div>
        </div>
      </div>
      <div class="debt-right">
        <div class="debt-amount">${formatAmount(b.shuma)}</div>
        <button class="btn-delete" title="Fshi" data-id="${b._id}">✕</button>
      </div>`;
    listEl.appendChild(item);
  });
}

function escHtml(str) {
  return str.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ── Add Debt ───────────────────────────────────────
addForm.addEventListener('submit', async e => {
  e.preventDefault();
  const emri  = emriInput.value.trim();
  const shuma = parseFloat(shumaInput.value);

  if (!emri)        return showMsg('Ju lutem shkruani emrin.');
  if (!shuma || shuma <= 0) return showMsg('Shuma duhet të jetë pozitive.');

  try {
    const res  = await fetch(API, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ emri, shuma })
    });
    const data = await res.json();

    if (!res.ok) return showMsg(data.mesazh || 'Gabim gjatë shtimit.');

    showMsg('Borxhi u shtua me sukses! ✓', 'success');
    addForm.reset();
    loadBorxhet();
  } catch {
    showMsg('Gabim: nuk mund të shtohet borxhi.');
  }
});

// ── Delete (click delegation) ──────────────────────
listEl.addEventListener('click', e => {
  const btn = e.target.closest('.btn-delete');
  if (!btn) return;
  pendingDeleteId = btn.dataset.id;
  overlay.classList.add('active');
});

// ── Modal actions ──────────────────────────────────
btnCancel.addEventListener('click', closeModal);
overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

function closeModal() {
  overlay.classList.remove('active');
  pendingDeleteId = null;
}

btnConfirm.addEventListener('click', async () => {
  if (!pendingDeleteId) return;
  try {
    await fetch(`${API}/${pendingDeleteId}`, { method: 'DELETE' });
    closeModal();
    loadBorxhet();
  } catch {
    showMsg('Gabim gjatë fshirjes.');
    closeModal();
  }
});

// ── Init ───────────────────────────────────────────
loadBorxhet();
